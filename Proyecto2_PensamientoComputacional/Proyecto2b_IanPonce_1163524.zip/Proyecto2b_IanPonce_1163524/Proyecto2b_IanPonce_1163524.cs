﻿using System;
using System.Collections.Generic;

namespace Proyecto2b_IanPonce_1163524
{
    // Ian Ponce
    // Seccion 17
    class Program
    {
        static List<Transaction> transactions = new List<Transaction>();
        static List<ThirdPartyAccount> thirdPartyAccounts = new List<ThirdPartyAccount>();
        static int thirdPartyAccountId = 1;

        static void Main(string[] args)
        {
            // Variables
            string tipoCuenta = "";
            string nombre = "";
            string dpi = "";
            string direccion = "";
            string telefono = "";
            double saldoInicial = 2500;
            double saldoActual = saldoInicial;
            int opcion;

            // Solicitar datos de la cuenta con validación
            tipoCuenta = SolicitarDatosAlfabeticos("Ingrese el tipo de cuenta: ");
            nombre = SolicitarDatosAlfabeticos("Ingrese su nombre: ");
            dpi = SolicitarDPI("Ingrese su DPI (5 caracteres): ");
            direccion = SolicitarDatosAlfabeticos("Ingrese su dirección: ");
            telefono = SolicitarTelefono("Ingrese su número de teléfono: ");

            // Bucle principal
            do
            {
                // Mostrar menú de opciones
                Console.WriteLine(" Menú de opciones ");
                Console.WriteLine("1. Ver información de la cuenta");
                Console.WriteLine("2. Comprar producto financiero");
                Console.WriteLine("3. Vender producto financiero");
                Console.WriteLine("4. Abonar a cuenta");
                Console.WriteLine("5. Simular paso del tiempo");
                Console.WriteLine("6. Mantenimiento de cuentas de terceros");
                Console.WriteLine("7. Realizar transferencias a otras cuentas");
                Console.WriteLine("8. Pago de servicios");
                Console.WriteLine("9. Imprimir informe de transacciones");
                Console.WriteLine("10. Salir");

                Console.Write("Seleccione una opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        // Ver información de la cuenta
                        Console.WriteLine("Información de la cuenta:");
                        Console.WriteLine("Tipo de cuenta: " + tipoCuenta);
                        Console.WriteLine("Nombre del dueño de la cuenta: " + nombre);
                        Console.WriteLine("DPI: " + dpi);
                        Console.WriteLine("Dirección: " + direccion);
                        Console.WriteLine("Número de teléfono: " + telefono);
                        Console.WriteLine("Saldo actual: " + saldoActual);
                        break;
                    case 2:
                        // Comprar producto financiero
                        if (saldoActual >= 0)
                        {
                            double monto = saldoActual * 0.1;
                            saldoActual -= monto;
                            RegistrarTransaccion(monto, "Debito");
                            Console.WriteLine("Se ha realizado la compra de producto financiero. Nuevo saldo: " + saldoActual);
                        }
                        else
                        {
                            Console.WriteLine("No se puede realizar la compra de un producto financiero. Saldo insuficiente.");
                        }
                        break;
                    case 3:
                        // Vender producto financiero
                        if (saldoActual > 500)
                        {
                            double monto = saldoActual * 0.11;
                            saldoActual += monto;
                            RegistrarTransaccion(monto, "Credito");
                            Console.WriteLine("Se ha vendido producto financiero. Nuevo saldo: " + saldoActual);
                        }
                        else
                        {
                            Console.WriteLine("No se puede vender producto financiero. Saldo insuficiente.");
                        }
                        break;
                    case 4:
                        // Abonar a cuenta
                        if (saldoActual < 500 && saldoActual > 0)
                        {
                            double monto = saldoActual;
                            saldoActual *= 2;
                            RegistrarTransaccion(monto, "Credito");
                            Console.WriteLine("Se ha abonado a la cuenta. Nuevo saldo: " + saldoActual);
                        }
                        else
                        {
                            Console.WriteLine("No se puede abonar a la cuenta. Saldo insuficiente o máximo alcanzado.");
                        }
                        break;
                    case 5:
                        // Simular paso del tiempo
                        Console.Write("Ingrese el periodo de capitalización (1 o 2): ");
                        int periodo = int.Parse(Console.ReadLine());

                        if (periodo == 1 || periodo == 2)
                        {
                            double interes = saldoActual * 0.02 * periodo;
                            saldoActual += interes;
                            RegistrarTransaccion(interes, "Credito");
                            Console.WriteLine("Se ha simulado el paso del tiempo. Nuevo saldo: " + saldoActual);
                        }
                        else
                        {
                            Console.WriteLine("Periodo de capitalización inválido.");
                        }
                        break;
                    case 6:
                        // Mantenimiento de cuentas de terceros
                        MantenimientoCuentasTerceros();
                        break;
                    case 7:
                        // Realizar transferencias a otras cuentas
                        RealizarTransferencias(saldoActual, ref saldoActual);
                        break;
                    case 8:
                        // Pago de servicios
                        PagoDeServicios(ref saldoActual);
                        break;
                    case 9:
                        // Imprimir informe de transacciones
                        ImprimirInformeTransacciones();
                        break;
                    case 10:
                        // Salir
                        Console.WriteLine("Gracias por utilizar nuestro sistema.");
                        break;
                    default:
                        Console.WriteLine("Opción inválida. Por favor, seleccione una opción que sea válida.");
                        break;
                }

            } while (opcion != 10);
        }

        // Método para solicitar datos alfabéticos
        static string SolicitarDatosAlfabeticos(string mensaje)
        {
            string dato;
            bool esValido;
            do
            {
                Console.Write(mensaje);
                dato = Console.ReadLine();
                esValido = ValidarAlfabetico(dato);
                if (!esValido)
                {
                    Console.WriteLine("Dato inválido. Solo se permiten caracteres alfabéticos.");
                }
            } while (!esValido);
            return dato;
        }

        // Método para solicitar DPI con validación de longitud y caracteres numéricos
        static string SolicitarDPI(string mensaje)
        {
            string dato;
            bool esValido;
            do
            {
                Console.Write(mensaje);
                dato = Console.ReadLine();
                esValido = ValidarDPI(dato);
                if (!esValido)
                {
                    Console.WriteLine("Dato inválido. El DPI debe contener exactamente 5 caracteres numéricos.");
                }
            } while (!esValido);
            return dato;
        }

        // Método para solicitar número de teléfono
        static string SolicitarTelefono(string mensaje)
        {
            string dato;
            bool esValido;
            do
            {
                Console.Write(mensaje);
                dato = Console.ReadLine();
                esValido = ValidarNumerico(dato);
                if (!esValido)
                {
                    Console.WriteLine("Dato inválido. El número de teléfono debe contener solo caracteres numéricos.");
                }
            } while (!esValido);
            return dato;
        }

        // Método para validar que un dato es alfabético
        static bool ValidarAlfabetico(string dato)
        {
            foreach (char c in dato)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    return false;
                }
            }
            return true;
        }

        // Método para validar DPI
        static bool ValidarDPI(string dpi)
        {
            if (dpi.Length != 5)
            {
                return false;
            }
            foreach (char c in dpi)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        // Método para validar datos numéricos
        static bool ValidarNumerico(string dato)
        {
            foreach (char c in dato)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        // Método para registrar transacciones
        static void RegistrarTransaccion(double monto, string tipo)
        {
            transactions.Add(new Transaction
            {
                Fecha = DateTime.Now,
                Monto = monto,
                Tipo = tipo
            });
        }

        // Método para imprimir el informe de transacciones
        static void ImprimirInformeTransacciones()
        {
            Console.WriteLine("Informe de Transacciones:");
            foreach (var transaction in transactions)
            {
                Console.WriteLine($"{transaction.Fecha} - {transaction.Tipo} - Monto: {transaction.Monto}");
            }
        }

        // Método para mantenimiento de cuentas de terceros
        static void MantenimientoCuentasTerceros()
        {
            int opcion;
            do
            {
                Console.WriteLine("1. Crear cuenta de tercero");
                Console.WriteLine("2. Eliminar cuenta de tercero");
                Console.WriteLine("3. Actualizar cuenta de tercero");
                Console.WriteLine("4. Regresar al menú principal");

                Console.Write("Seleccione una opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        CrearCuentaTercero();
                        break;
                    case 2:
                        EliminarCuentaTercero();
                        break;
                    case 3:
                        ActualizarCuentaTercero();
                        break;
                    case 4:
                        Console.WriteLine("Regresando al menú principal...");
                        break;
                    default:
                        Console.WriteLine("Opción inválida. Por favor, seleccione una opción que sea válida.");
                        break;
                }

            } while (opcion != 4);
        }

        // Método para crear una cuenta de tercero
        static void CrearCuentaTercero()
        {
            string nombre = SolicitarDatosAlfabeticos("Ingrese el nombre del cuentahabiente: ");
            string numeroCuenta = SolicitarTelefono("Ingrese el número de cuenta: ");
            string nombreBanco = SolicitarDatosAlfabeticos("Ingrese el nombre del banco: ");
            Console.Write("Ingrese el monto a transferir: ");
            double monto = double.Parse(Console.ReadLine());
            Console.Write("Ingrese la moneda (quetzales o dólares): ");
            string moneda = Console.ReadLine();

            thirdPartyAccounts.Add(new ThirdPartyAccount
            {
                Id = thirdPartyAccountId++,
                Nombre = nombre,
                NumeroCuenta = numeroCuenta,
                NombreBanco = nombreBanco,
                Monto = monto,
                Moneda = moneda
            });

            Console.WriteLine("Cuenta de tercero creada exitosamente.");
        }

        // Método para eliminar una cuenta de tercero
        static void EliminarCuentaTercero()
        {
            Console.Write("Ingrese el ID de la cuenta a eliminar: ");
            int id = int.Parse(Console.ReadLine());
            var cuenta = thirdPartyAccounts.Find(c => c.Id == id);
            if (cuenta != null)
            {
                thirdPartyAccounts.Remove(cuenta);
                Console.WriteLine("Cuenta de tercero eliminada exitosamente.");
            }
            else
            {
                Console.WriteLine("No se encontró una cuenta con el ID especificado.");
            }
        }

        // Método para actualizar una cuenta de tercero
        static void ActualizarCuentaTercero()
        {
            Console.Write("Ingrese el ID de la cuenta a actualizar: ");
            int id = int.Parse(Console.ReadLine());
            var cuenta = thirdPartyAccounts.Find(c => c.Id == id);
            if (cuenta != null)
            {
                cuenta.Nombre = SolicitarDatosAlfabeticos("Ingrese el nuevo nombre del cuentahabiente: ");
                cuenta.NumeroCuenta = SolicitarTelefono("Ingrese el nuevo número de cuenta: ");
                cuenta.NombreBanco = SolicitarDatosAlfabeticos("Ingrese el nuevo nombre del banco: ");
                Console.Write("Ingrese el nuevo monto a transferir: ");
                cuenta.Monto = double.Parse(Console.ReadLine());
                Console.Write("Ingrese la nueva moneda (quetzales o dólares): ");
                cuenta.Moneda = Console.ReadLine();
                Console.WriteLine("Cuenta de tercero actualizada exitosamente.");
            }
            else
            {
                Console.WriteLine("No se encontró una cuenta con el ID especificado.");
            }
        }

        // Método para realizar transferencias a otras cuentas
        static void RealizarTransferencias(double saldoActual, ref double saldoActualRef)
        {
            Console.WriteLine("Cuentas de terceros disponibles:");
            foreach (var cuenta in thirdPartyAccounts)
            {
                Console.WriteLine($"ID: {cuenta.Id}, Nombre: {cuenta.Nombre}, Número de cuenta: {cuenta.NumeroCuenta}, Banco: {cuenta.NombreBanco}");
            }

            Console.Write("Ingrese el ID de la cuenta a la que desea transferir: ");
            int id = int.Parse(Console.ReadLine());
            var cuentaDestino = thirdPartyAccounts.Find(c => c.Id == id);
            if (cuentaDestino != null)
            {
                Console.Write("Ingrese el monto a transferir (200 o 2000): ");
                double monto = double.Parse(Console.ReadLine());
                if (monto != 200 && monto != 2000)
                {
                    Console.WriteLine("Monto inválido. Solo se permiten transferencias de 200 o 2000 quetzales.");
                    return;
                }

                if (saldoActual >= monto)
                {
                    saldoActualRef -= monto;
                    RegistrarTransaccion(monto, "Debito");
                    Console.WriteLine($"Transferencia realizada exitosamente. Nuevo saldo: {saldoActualRef}");
                }
                else
                {
                    Console.WriteLine("Saldo insuficiente para realizar la transferencia.");
                }
            }
            else
            {
                Console.WriteLine("No se encontró una cuenta con el ID especificado.");
            }
        }

        // Método para pago de servicios
        static void PagoDeServicios(ref double saldoActual)
        {
            Console.WriteLine("Proveedores de servicios:");
            Console.WriteLine("1. Empresa de agua");
            Console.WriteLine("2. Empresa Eléctrica");
            Console.WriteLine("3. Telefónica");

            Console.Write("Seleccione un proveedor de servicios: ");
            int opcion = int.Parse(Console.ReadLine());

            string proveedor = opcion switch
            {
                1 => "Empresa de agua",
                2 => "Empresa Eléctrica",
                3 => "Telefónica",
                _ => null
            };

            if (proveedor == null)
            {
                Console.WriteLine("Opción inválida.");
                return;
            }

            Console.Write("Ingrese el monto del pago: ");
            double monto = double.Parse(Console.ReadLine());

            if (saldoActual >= monto)
            {
                saldoActual -= monto;
                RegistrarTransaccion(monto, "Debito");
                Console.WriteLine($"Pago a {proveedor} realizado exitosamente. Nuevo saldo: {saldoActual}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para realizar el pago.");
            }
        }
    }

    // Clase para registrar transacciones
    class Transaction
    {
        public DateTime Fecha { get; set; }
        public double Monto { get; set; }
        public string Tipo { get; set; }
    }

    // Clase para cuentas de terceros
    class ThirdPartyAccount
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string NumeroCuenta { get; set; }
        public string NombreBanco { get; set; }
        public double Monto { get; set; }
        public string Moneda { get; set; }
    }
}

